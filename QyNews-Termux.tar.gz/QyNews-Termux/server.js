import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/news', async (req, res) => {
  const q = String(req.query.q || 'Indonesia').slice(0, 100);
  const lang = String(req.query.lang || 'id');
  const country = String(req.query.country || 'id');
  const key = process.env.GNEWS_API_KEY;
  if (!key || key.includes('ISI_API_KEY')) return res.status(500).json({error:'API key belum diatur. Isi GNEWS_API_KEY di file .env.'});
  try {
    const url = new URL('https://gnews.io/api/v4/search');
    url.searchParams.set('q', q); url.searchParams.set('lang', lang); url.searchParams.set('country', country); url.searchParams.set('max', '10'); url.searchParams.set('apikey', key);
    const response = await fetch(url);
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({error:data.errors?.join(', ') || data.message || 'Gagal mengambil berita'});
    res.json(data);
  } catch (e) { res.status(500).json({error:'Server gagal terhubung ke API berita.'}); }
});

app.listen(PORT, () => console.log(`QyNews berjalan di http://localhost:${PORT}`));
